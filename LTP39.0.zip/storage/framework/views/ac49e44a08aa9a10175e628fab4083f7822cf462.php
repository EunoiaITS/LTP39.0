<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Parking Kori</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- stylesheet css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
    <!-- mordernizr css -->
    <script src="<?php echo e(asset('public/assets/js/vendor/modernizr.custom.97074.js')); ?>"></script>
</head>
<body>

<div class="parking-kori clearfix">
    <div class="container">
        <div class="parking-kori-login clearfix">
            <div class="parking-kori-logo text-center">
                <img src="<?php echo e(asset('public/assets/img/pklogo.png')); ?>" alt="parking kori">
            </div>
            <form method="post" action="<?php echo e(route('login')); ?>" class="parking-login clearfix">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="user-name" class="usr-lock"><i class="fas fa-user"></i></label>
                    <input type="email" placeholder="E-mail" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                    <input type="password" placeholder="Password" class="form-control" name="password" required>
                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="clearfix"></div>
                <button type="submit" class="btn-info btn btn-login">Login</button>
                <a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
            </form>
        </div>
        <div class="footer-content text-center">
            <p>A Product of <a href="#">DexHub</a></p>
            <p>Powered by <a href="#">Eunoia I.T Solutions</a></p>
        </div>
    </div>
</div>


<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- main js file -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo e(asset('public/assets/js/vendor/jquery-3.2.1.min.js')); ?>"><\/script>')</script>
<!-- bootstrap css -->
<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/niceScroll.min.js')); ?>"></script>
<!-- main js file -->
<script src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>
</body>
</html>





    
        
            
                

                
                    
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    

                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                

                                
                                    
                                
                            
                        
                    
                
            
        
    


