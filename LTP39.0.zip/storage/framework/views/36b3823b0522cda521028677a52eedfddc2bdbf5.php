<?php $__env->startSection('content'); ?>

    <!-- main-content area -->
    <div class="dashboard-main-content">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 dashboad-title">
                    <h2>Settings <img src="<?php echo e(url('public/assets/img/down-arrow.png')); ?>" alt=""></h2>
                    <h4 class="date">Exempted Time</h4>
                    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12 padding-0">
                    <div class="col-sm-6 col-md-6">
                        <div class="exampted-time-area">
                            <form method="post" id="time" action="<?php echo e(url('/settings/exempted-setting')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="vechicle-select">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Exemted Time</label>
                                        <input type="text" name="from" class="form-control form-exampted from" id="datetimepicker3"	placeholder="Form" value="<?php if(!empty($exTime)): ?><?php echo e($exTime->from); ?><?php endif; ?>">
                                        <input type="text" name="to" class="form-control form-exampted to" id="datetimepicker4" placeholder="To" value="<?php if(!empty($exTime)): ?><?php echo e($exTime->to); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="clearfix" style="height: 20px"></div>
                                <?php if(!empty($exTime)): ?>
                                    <input type="hidden" name="action" value="ex-time">
                                    <input type="hidden" name="time_id" value="<?php echo e($exTime->id); ?>">
                                    <?php else: ?>
                                    <input type="hidden" name="action" value="time">
                                    <?php endif; ?>
                                <div class="submit-forget-password clearfix">
                                    <button type="button" class="btn-info btn btn-login time" data-toggle="modal" data-target="#myModal1">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6">
                        <div class="exampted-time-area">
                            <form method="post" id="duration" action="<?php echo e(url('/settings/exempted-setting')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="vechicle-select">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Exemted Duration</label>
                                        <input type="text" name="duration" class="form-control e-duration" placeholder="minutes" value="<?php if(!empty($exDuration)): ?><?php echo e($exDuration->duration); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <?php if(!empty($exDuration)): ?>
                                    <input type="hidden" name="action" value="ex-duration">
                                    <input type="hidden" name="duration_id" value="<?php echo e($exDuration->id); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="action" value="duration">
                                <?php endif; ?>
                                <div class="submit-forget-password">
                                    <button type="button" class="btn-info btn btn-login duration" data-toggle="modal" data-target="#myModal2">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>