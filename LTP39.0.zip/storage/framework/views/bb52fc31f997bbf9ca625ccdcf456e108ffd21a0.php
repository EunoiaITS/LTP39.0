<?php $__env->startSection('content'); ?>

    <!-- main-content area -->
    <div class="dashboard-main-content clearfix">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 dashboad-title">
                    <h2>Settings <img src="img/down-arrow.png" alt=""></h2>
                    <h4 class="date">Assign Parking</h4>
                </div>
                <div class="col-sm-12 padding-0">
                    <div class="col-sm-6 col-md-3 col-sm-6 col-md-offset-0 col-sm-offset-3">
                        <div class="total-parking-area">
                            <div class="total-date--icon">
                                <span>Total Parking</span>
                            </div>
                            <div class="date-timepicker">
                                <h4 class="date-span"><?php $total = 0; ?><?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $total+=$p->amount; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php echo e($total); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-offset-3 col-sm-offset-2 col-md-6">
                        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php if(isset($errors)): ?>
                            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="employee-form form-employee-center clearfix">
                            <form method="post" action="<?php echo e(url('/settings/assign-parking')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="assign-v-select vechicle-select">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Vehicle Type</label>
                                        <select class="form-control get-select-picker" name="vehicle_id" id="exampleFormControlSelect1" title="Vechile Category">
                                            <?php $__currentLoopData = $vt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($v->id); ?>" <?php if(old('vehicle_id') == $v->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($v->type_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="user-crname" class="usr-lock"><i class="fas fa-car"></i></label>
                                    <input type="text" placeholder="Total Parking" name="amount" class="form-control" value="<?php echo e(old('amount')); ?>" required>
                                </div>
                                <div class="submit-forget-password">
                                    <input type="hidden" name="action" value="assign">
                                    <button type="submit" class="btn-info btn btn-login">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-sm-12 col-md-offset-2">
                    <div class="employee-table-center clearfix">
                        <table id="example" class="table" style="width:100%">
                            <thead>
                            <tr>
                                <th>Serial</th>
                                <th>Vehicle Type Number</th>
                                <th>Total Number</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($p->vehicle->type_name); ?></td>
                                    <td><?php echo e($p->amount); ?></td>
                                    <td>
                                        <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#edit-p-<?php echo e($p->id); ?>">Edit</button>
                                        <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#delete-<?php echo e($p->id); ?>">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>