<!--
	block modal
	-->
<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="myModal<?php echo e($client->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div  class="modal-dialog" role="document">
            <div class="modal-content modal-form">
                <form method="post" action="<?php echo e(url('/clients-list')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body text-center modal-padding">
                        <p>Are you sure you want to <?php if(isset($client->data->status)): ?><?php if($client->data->status == 'block'): ?> <?php echo e('unblock'); ?> <?php else: ?> <?php echo e('block'); ?> <?php endif; ?> <?php endif; ?><strong><?php if(isset($client->data->name)): ?><?php echo e($client->data->name); ?><?php endif; ?></strong>?</p>
                        <input type="hidden" name="status" value="<?php if(isset($client->data->status)): ?><?php if($client->data->status == 'block'): ?> <?php echo e('unblock'); ?> <?php else: ?> <?php echo e('block'); ?> <?php endif; ?> <?php endif; ?>">
                        <input type="hidden" name="client_id" value="<?php echo e($client->user_id); ?>">
                        <input type="hidden" name="action" value="blocking">
                        <button type="submit" class="btn btn-default">Yes</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--
	delete modal
	-->
<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="myModalDel<?php echo e($client->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div  class="modal-dialog" role="document">
            <div class="modal-content modal-form">
                <form method="post" action="<?php echo e(url('/clients-list')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body text-center modal-padding">
                        <p>Are you sure you want to delete <strong><?php if(isset($client->data->name)): ?><?php echo e($client->data->name); ?><?php endif; ?></strong>?</p>
                        <input type="hidden" name="client_id" value="<?php echo e($client->user_id); ?>">
                        <input type="hidden" name="action" value="delete">
                        <button type="submit" class="btn btn-default">Yes</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>