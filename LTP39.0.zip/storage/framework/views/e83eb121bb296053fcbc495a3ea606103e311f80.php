<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModal-<?php echo e($dv->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form modal-device">
            <div class="modal-body text-center modal-padding">
                <h3>Edit Charger Serial</h3>
                <form action="<?php echo e(url('/manage-device')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="user-name">Charger Serial</label>
                        <input type="hidden" name="device_id" value="<?php echo e($dv->id); ?>">
                        <input type="text" name="charger_id" value="<?php echo e($dv->charger_id); ?>" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-default">Confirm</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModaldel-<?php echo e($dv->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form action="<?php echo e(url('/delete-device')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                    <div class="modal-body text-center modal-padding">
                        <p>Are you sure?</p>
                        <input type="hidden" name="device_id" value="<?php echo e($dv->id); ?>">
                        <button type="submit" class="btn btn-default">Yes</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>