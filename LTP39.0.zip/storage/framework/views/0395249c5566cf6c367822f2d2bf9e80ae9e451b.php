<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModalEmp-<?php echo e($e->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <h3>Edit Employee</h3>
                <form action="<?php echo e(url('/edit-employee')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-user"></i></label>
                        <input name="name" type="text" placeholder="Employee Name" class="form-control" value="<?php echo e($e->name); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-phone"></i></label>
                        <input name="phone" type="text" placeholder="Phone" class="form-control" value="<?php echo e($e->phone); ?>" required>
                    </div>
                    <input type="hidden" name="emp_id" value="<?php echo e($e->id); ?>">
                    <button type="submit" class="btn btn-default">Confirm</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<!--=====================
edit password modal
=========================-->
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModalPass-<?php echo e($e->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <h3>Edit Password</h3>
                <form action="<?php echo e(url('/edit-password')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group clearfix">
                        <label for="user-name" class="usr-name-lock"><i class="fas fa-user"></i></label>
                        <span class="emp-name"><?php echo e($e->name); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input name="password" type="password" placeholder="Password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input name="repass" type="password" placeholder="Re-type Password" class="form-control" required>
                    </div>
                    <input type="hidden" name="emp_id" value="<?php echo e($e->id); ?>">
                    <button type="submit" class="btn btn-default">Confirm</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--
block/unblock modal
-->
<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModalBlock-<?php echo e($e->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form action="<?php echo e(url('/blocking')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body text-center modal-padding">
                    <p>Are you sure you want to block <strong><?php echo e($e->name); ?></strong>?</p>
                    <input type="hidden" name="emp_id" value="<?php echo e($e->id); ?>">
                    <input type="hidden" name="status" value="<?php if($e->status == 'block'): ?> <?php echo e('unblock'); ?> <?php else: ?> <?php echo e('block'); ?> <?php endif; ?>">
                    <button type="submit" class="btn btn-default">Yes</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>