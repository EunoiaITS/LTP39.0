<!--=====================
	Reset password modal 
	=========================-->
<div class="modal fade" id="myModalz" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <h3>Reset Password</h3>
                <form method="post" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>" id="reset-pass">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="password" placeholder="Type new Password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="repass" placeholder="Re-type new Password" class="form-control" required>
                    </div>
                    <input type="hidden" name="action" value="pass">
                </form>
                <button type="submit" form="reset-pass" class="btn btn-default">Confirm</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!--=====================
create manager modal
=========================-->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <h3>Create Manager</h3>
                <form method="post" id="create-managers" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-id-badge"></i></label>
                        <input type="text" name="manager_id" placeholder="ID" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-user"></i></label>
                        <input type="text" name="name" placeholder="Name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="far fa-envelope"></i></label>
                        <input type="email" name="email" placeholder="Email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="password" placeholder="Password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="repass" placeholder="Confirm Password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-phone"></i></label>
                        <input type="text" name="phone" placeholder="Phone" class="form-control" required>
                    </div>
                    <input type="hidden" name="role" value="manager">
                    <input type="hidden" name="action" value="crt-mngr">
                </form>
                <button type="submit" form="create-managers" class="btn btn-default">Create</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--=====================
edit manager modal
=========================-->
<div class="modal fade" id="edit-manager-<?php echo e($cm->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <h3>Edit Manager</h3>
                <form method="post" id="edit-mngr-<?php echo e($cm->id); ?>" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-id-badge"></i></label>
                        <input type="text" name="manager_id" placeholder="ID" class="form-control" value="<?php echo e($cm->manager_id); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-user"></i></label>
                        <input type="text" name="name" placeholder="Name" class="form-control" value="<?php echo e($cm->data->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="far fa-envelope"></i></label>
                        <input type="email" name="email" placeholder="Email" class="form-control" value="<?php echo e($cm->data->email); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="password" placeholder="Password" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-lock"></i></label>
                        <input type="password" name="repass" placeholder="Confirm Password" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="user-name" class="usr-lock"><i class="fas fa-phone"></i></label>
                        <input type="text" name="phone" placeholder="Phone" class="form-control" value="<?php echo e($cm->phone); ?>">
                    </div>
                    <input type="hidden" name="manager_id" value="<?php echo e($cm->id); ?>">
                    <input type="hidden" name="action" value="edit-mngr">
                </form>
                <button type="submit" form="edit-mngr-<?php echo e($cm->id); ?>" class="btn btn-default">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!--
delete manager modal
-->
<div class="modal fade" id="delete-manager-<?php echo e($cm->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <form method="post" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
            <?php echo e(csrf_field()); ?>

        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <p>Are you sure you want to Delete <strong><?php echo e($cm->data->name); ?></strong>?</p>
                <input type="hidden" name="action" value="delete-mngr">
                <input type="hidden" name="manager_id" value="<?php echo e($cm->id); ?>">
                <button type="submit" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
        </div>
        </form>
    </div>
</div>

<!--
block modal
-->
<div class="modal fade" id="block-manager-<?php echo e($cm->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form method="post" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
                <?php echo e(csrf_field()); ?>

            <div class="modal-body text-center modal-padding">
                <p>Are you sure you want to <?php if($cm->data->status == 'block'): ?> <?php echo e('unblock'); ?> <?php else: ?> <?php echo e('block'); ?> <?php endif; ?> <strong><?php echo e($cm->data->name); ?></strong>?</p>
                <input type="hidden" name="action" value="stat-mngr">
                <input type="hidden" name="manager_id" value="<?php echo e($cm->id); ?>">
                <input type="hidden" name="status" value="<?php if($cm->data->status == 'block'): ?> <?php echo e('unblock'); ?> <?php else: ?> <?php echo e('block'); ?> <?php endif; ?>">
                <button type="submit" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!--================
Assign device modal
=========================-->
<div class="modal fade model-that-hide" id="myModaltable" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <table id="example3" class="table" style="width:100%">
                    <thead>
                    <tr>
                        <th>Serial</th>
                        <th>ID</th>
                        <th>Factory Serial</th>
                        <th>Select Device</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $d = 1; ?>
                    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d++); ?></td>
                        <td><?php echo e($device->device_id); ?></td>
                        <td><?php echo e($device->factory_id); ?></td>
                        <td>
                            <input type="checkbox" class="form-check-input dev-in" name="dev_in" id="exampleCheck1" value="<?php echo e($device->device_id); ?>">
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <button type="button" class="btn btn-default" id="modal-hide" data-toggle="modal" data-target="#assignmodal">Assign</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!--
assign device modal
-->
<div class="modal fade" id="assignmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form method="post" id="devs" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
            <?php echo e(csrf_field()); ?>

                <div class="modal-body text-center modal-padding">
                <p>Are you sure you want to ADD
                <ol id="devices">
                </ol>
                </p>
                <input type="hidden" name="action" value="dev">
                <button type="submit" form="devs" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
            </form>
        </div>
    </div>
</div>

<?php $__currentLoopData = $assigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--
delete device modal
-->
<div class="modal fade" id="device-<?php echo e($ass->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form method="post" id="devs" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>">
                <?php echo e(csrf_field()); ?>

            <div class="modal-body text-center modal-padding">
                <p>Are you sure you want to delete <strong><?php echo e($ass->device_id); ?></strong> ?
                </p>
                <input type="hidden" name="action" value="remove">
                <input type="hidden" name="device_id" value="<?php echo e($ass->id); ?>">
                <button type="submit" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
                </form>
        </div>
    </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>