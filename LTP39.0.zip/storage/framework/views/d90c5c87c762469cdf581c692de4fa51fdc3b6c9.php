<?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!--=====================
edit manager modal
=========================-->
    <div class="modal fade" id="edit-p-<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div  class="modal-dialog" role="document">
            <div class="modal-content modal-form">
                <div class="modal-body text-center modal-padding">
                    <h3>Edit Assign Amount</h3>
                    <form method="post" id="edit-<?php echo e($p->id); ?>" action="<?php echo e(url('/settings/assign-parking')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="user-name" class="usr-lock"><i class="fas fa-car"></i></label>
                            <input type="text" name="amount" placeholder="Name" class="form-control" value="<?php echo e($p->amount); ?>">
                        </div>
                        <input type="hidden" name="setting_id" value="<?php echo e($p->id); ?>">
                        <input type="hidden" name="action" value="edit">
                    </form>
                    <button type="submit" form="edit-<?php echo e($p->id); ?>" class="btn btn-default">Save</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

<!--
	delete modal 
	-->
<div class="modal fade" id="delete-<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form method="post" id="edit-<?php echo e($p->id); ?>" action="<?php echo e(url('/settings/assign-parking')); ?>">
                <?php echo e(csrf_field()); ?>

            <div class="modal-body text-center modal-padding">
                <div class="icon-delete text-center"><i class="fas fa-trash"></i></div>
                <p>Are you sure you want to delete this?</p>
                <input type="hidden" name="setting_id" value="<?php echo e($p->id); ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
            </form>
        </div>
    </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>