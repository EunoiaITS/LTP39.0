<?php $__env->startSection('content'); ?>

    <!-- main-content area -->
    <div class="dashboard-main-content clearfix">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 dashboad-title">
                    <h2>Client Details <img src="<?php echo e(asset('public/assets/img/down-arrow.png')); ?>" alt=""></h2>
                    <h4 class="date"><?php echo e($client->data->name); ?></h4>
                    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="employee-form form-employee-center clearfix">
                        <form method="post" action="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="user-id">Email</label><br>
                                <span class="email"><?php echo e($client->data->email); ?></span>
                            </div>
                            <div class="form-group">
                                <label for="user-id" class="usr-lock"><i class="fas fa-phone"></i></label>
                                <input type="text" name="phone" placeholder="Phone" class="form-control" id="phone-no" value="<?php echo e($client->phone); ?>" readonly>
                            </div>
                            <div class="form-group clearfix">
                                <label for="payment-terms">Payment Term</label>
                                <div class="clearfix"></div>
                                <?php if(isset($client->payment_file)): ?>
                                    <div class="file-picutre">
                                        <img src="<?php echo e(asset('public/uploads/clients/payment_files/'.$client->payment_file)); ?>" alt="image">
                                    </div>
                                <?php endif; ?>
                                <div class="file btn btn-sm btn-primary ">
                                    <div class="upload-icon"><i class="fas fa-cloud-upload-alt"></i></div><span>Browse File</span>
                                    <input type="file" class="input-upload" name="file" id="file-up" disabled>
                                </div>
                            </div>
                            <input type="hidden" name="action" value="edit-data">
                            <div class="submit-forget-password">
                                <button class="btn-info btn btn-login" type="button" data-toggle="modal" data-target="#myModalz">Reset Password</button>
                                <button class="btn-info btn btn-login" type="submit" id="btn-save" disabled>Save</button>
                            </div>
                        </form>
                        <!-- edit clients -->
                        <div class="edit-icon-absolute">
                            <i class="far fa-edit edit-icon-option" id="enable-edit"></i>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 dashboad-title">
                    <h2>Manager List <div class="plus-icon" data-toggle="modal" data-target="#myModal1"><i class="fas fa-plus-circle"></i></div></h2>
                    <?php if(session()->has('success_m')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('success_m')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('error_m')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session()->get('error_m')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="employee-table-center clearfix">
                        <table id="example" class="table" style="width:100%">
                            <thead>
                            <tr>
                                <th>Serial</th>
                                <th>ID</th>
                                <th> Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($cm->manager_id); ?></td>
                                <td><?php echo e($cm->data->name); ?></td>
                                <td>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#edit-manager-<?php echo e($cm->id); ?>">Edit</button>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#delete-manager-<?php echo e($cm->id); ?>">Delete</button>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#block-manager-<?php echo e($cm->id); ?>"><?php if($cm->data->status == 'block'): ?> <?php echo e('Unblock'); ?> <?php else: ?> <?php echo e('Block'); ?> <?php endif; ?></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <div class="col-sm-12 dashboad-title">
                    <h2>Device List <div class="plus-icon" data-toggle="modal" data-target="#myModaltable"><i class="fas fa-plus-circle"></i></div></h2>
                    <?php if(session()->has('success_d')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('success_d')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('error_d')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e(session()->get('error_d')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="employee-table-center clearfix">
                        <table id="example2" class="table" style="width:100%">
                            <thead>
                            <tr>
                                <th>Serial</th>
                                <th>ID</th>
                                <th>Factory Serial</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $ad = 1; ?>
                            <?php $__currentLoopData = $assigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ad++); ?></td>
                                <td><?php echo e($ass->device_id); ?></td>
                                <td><?php echo e($ass->factory_id); ?></td>
                                <td>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#device-<?php echo e($ass->id); ?>">Remove</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>