<?php $__env->startSection('content'); ?>

    <!-- main-content area -->
    <div class="dashboard-main-content clearfix">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 dashboad-title">
                    <h2>Create Client</h2>
                    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-12">
                    <div class="employee-form form-employee-center clearfix">
                        <form method="post" action="<?php echo e(url('/create-client')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="user-id" class="usr-lock"><i class="fas fa-id-badge"></i></label>
                                <input type="text" name="client_id" placeholder="ID" class="form-control" id="user-id" value="<?php echo e(old('client_id')); ?>" required>
                            </div>
                            <div class="vechicle-select">
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Client Type</label>
                                    <select class="form-control get-select-picker" name="client_type" id="exampleFormControlSelect1" title="Cleint Category">
                                        <option value="park" <?php if(old('client_type') == 'park'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Parking Client</option>
                                        <option value="ad" <?php if(old('client_type') == 'ad'): ?> <?php echo e('selected'); ?> <?php endif; ?>>Advertisement Client</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="user-name" class="usr-lock"><i class="fas fa-user"></i></label>
                                <input type="text" name="name" placeholder="name" class="form-control" id="user-name" value="<?php echo e(old('name')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="user-email" class="usr-lock"><i class="far fa-envelope"></i></label>
                                <input type="email" name="email" placeholder="Email" class="form-control" id="user-email" value="<?php echo e(old('email')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="user-password" class="usr-lock"><i class="fas fa-lock"></i></label>
                                <input type="password" name="password" placeholder="Password" class="form-control" id="user-password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm-password" class="usr-lock"><i class="fas fa-lock"></i></label>
                                <input type="password" name="repass" placeholder="Confirm Password" class="form-control" id="confirm-password" required>
                            </div>
                            <div class="form-group">
                                <label for="clint-phone" class="usr-lock"><i class="fas fa-phone"></i></label>
                                <input type="text" name="phone" placeholder="Phone" class="form-control" id="clint-phone" value="<?php echo e(old('phone')); ?>" required>
                            </div>

                            <div class="form-group clearfix">
                                <label for="payment-terms">Payment Terms</label>
                                <div class="clearfix"></div>
                                <div class="file btn btn-sm btn-primary ">
                                    <div class="upload-icon"><i class="fas fa-cloud-upload-alt"></i></div><span>Browse File</span>
                                    <input type="file" class="input-upload" name="file">
                                </div>
                            </div>

                            <input type="hidden" name="role" value="client">
                            <div class="submit-forget-password">
                                <button class="btn-info btn btn-login" type="submit">Create</button>
                                <button class="btn-info btn btn-login" type="button" onclick="window.location.reload();">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>