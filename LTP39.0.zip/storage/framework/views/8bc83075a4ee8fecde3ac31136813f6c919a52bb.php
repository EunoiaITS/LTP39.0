<?php $__env->startSection('content'); ?>
<!-- main-content area -->
<div class="dashboard-main-content clearfix">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 dashboad-title">
                <h2>Create Device</h2>
                <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php if(isset($errors)): ?>
                    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-sm-12">
                <div class="employee-form form-employee-center clearfix">
                    <form name="create_device" action="<?php echo e(url('/create-device')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="device-id" class="usr-lock"><i class="fas fa-id-badge"></i></label>
                            <input type="text" name="device_id" placeholder="ID" class="form-control" id="device-id" required>
                        </div>
                        <div class="form-group">
                            <label for="factory-serial">Factory Serial</label>
                            <input type="text" name="factory_id" placeholder="S/N002948928393289" class="form-control" id="factory-serial" required>
                        </div>
                        <div class="form-group">
                            <label for="charger-serial">Charger Serial</label>
                            <input type="text" name="charger_id" placeholder="S/N849484859389484" class="form-control" id="charger-serial">
                        </div>
                        <div class="submit-forget-password">
                            <button type="submit" class="btn-info btn btn-login">Create</button>
                            <button type="button" class="btn-info btn btn-login">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>