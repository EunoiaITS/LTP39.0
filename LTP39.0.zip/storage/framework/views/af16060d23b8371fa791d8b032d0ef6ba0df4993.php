<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content clearfix">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 dashboad-title">
                <h2>Manage Employees</h2>
                <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php if(isset($errors)): ?>
                    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-sm-12">
                <div class="employee-table-center clearfix">
                    <table id="example" class="table" style="width:100%">
                        <thead>
                        <tr>
                            <th>Serial</th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $count = 0; ?>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $count++; ?>
                        <tr>
                            <td><?php echo e($count); ?></td>
                            <td><?php echo e($e->employee_id); ?></td>
                            <td><?php echo e($e->name); ?></td>
                            <td><?php echo e($e->phone); ?></td>
                            <td><?php echo e($e->email); ?></td>
                            <td>
                                <div class="edit-icon icon-ed" data-toggle="modal" data-target="#myModalEmp-<?php echo e($e->id); ?>"><img src="<?php echo e(asset('/public/assets/img/edit-image.png')); ?>" alt=""></div>
                                <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#myModalPass-<?php echo e($e->id); ?>">Edit Password</button>
                                <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#myModalBlock-<?php echo e($e->id); ?>"><?php if($e->status == 'unblock'): ?> <?php echo e('Block'); ?> <?php else: ?> <?php echo e('Unblock'); ?> <?php endif; ?></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>