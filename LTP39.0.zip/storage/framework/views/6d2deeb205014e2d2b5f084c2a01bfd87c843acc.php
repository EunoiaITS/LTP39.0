<?php $__currentLoopData = $billing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade model-that-hide" id="myModal-<?php echo e($b->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <form id="bill<?php echo e($b->id); ?>" action="<?php echo e(url('/payment')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="transaction-id">Transaction ID</label>
                        <input type="text" name="transaction_id" placeholder="20463485223" class="form-control" required>
                        <input type="hidden" name="payment_id" value="<?php echo e($b->id); ?>">
                    </div>
                </form>
                <button type="button" class="btn btn-default" id="modal-hide" data-toggle="modal" data-target="#myModalCon-<?php echo e($b->id); ?>">Okay</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $billing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="myModalCon-<?php echo e($b->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <div class="modal-body text-center modal-padding">
                <p>Are you sure The Transaction is Done?</p>
                <button type="submit" form="bill<?php echo e($b->id); ?>" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>