<?php $__env->startSection('content'); ?>

    <!-- main-content area -->
    <div class="dashboard-main-content clearfix">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 dashboad-title">
                    <h2>Client <img src="<?php echo e(asset('public/assets/img/down-arrow.png')); ?>" alt=""></h2>
                    <h4 class="date">Manage Client</h4>
                    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="employee-table-center clearfix">
                        <div class="col-sm-4">
                            <div class="vechicle-select">
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Client Type</label>
                                    <select class="form-control get-select-picker" id="exampleFormControlSelect1" title="Cleint Category">
                                        <option value="">Parking Client</option>
                                        <option value="">Advertisement Client</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <table id="example" class="table" style="width:100%">
                            <thead>
                            <tr>
                                <th>Serial</th>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $sn = 1; ?>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sn++); ?></td>
                                <td><?php echo e($client->client_id); ?></td>
                                <td><?php if(isset($client->data->name)): ?><?php echo e($client->data->name); ?><?php endif; ?></td>
                                <td>
                                    <a href="<?php echo e(url('/client-details?client_id='.$client->client_id)); ?>"><button class="edit-icon btn btn-login">View Details</button></a>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#myModal<?php echo e($client->id); ?>"><?php if(isset($client->data->status)): ?><?php if($client->data->status == 'block'): ?> <?php echo e('Unblock'); ?> <?php else: ?> <?php echo e('Block'); ?> <?php endif; ?> <?php endif; ?></button>
                                    <button class="edit-icon btn btn-login" data-toggle="modal" data-target="#myModalDel<?php echo e($client->id); ?>">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>