<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!--=====================
edit manager modal
=========================-->
    <div class="modal fade" id="edit-<?php echo e($d->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div  class="modal-dialog" role="document">
            <div class="modal-content modal-form">
                <div class="modal-body text-center modal-padding">
                    <h3>Edit Vehicle Category</h3>
                    <form method="post" id="edit-v-<?php echo e($d->id); ?>" action="<?php echo e(url('/settings/vehicle-types')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="user-name" class="usr-lock"><i class="fas fa-id-badge"></i></label>
                            <input type="text" name="type_id" placeholder="ID" class="form-control" value="<?php echo e($d->type_id); ?>">
                        </div>
                        <div class="form-group">
                            <label for="user-name" class="usr-lock"><i class="fas fa-car"></i></label>
                            <input type="text" name="type_name" placeholder="Name" class="form-control" value="<?php echo e($d->type_name); ?>">
                        </div>
                        <input type="hidden" name="vehicle_id" value="<?php echo e($d->id); ?>">
                        <input type="hidden" name="action" value="edit">
                    </form>
                    <button type="submit" form="edit-v-<?php echo e($d->id); ?>" class="btn btn-default">Save</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

<!--
	block/unblock modal 
	-->
<div class="modal fade" id="delete-<?php echo e($d->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div  class="modal-dialog" role="document">
        <div class="modal-content modal-form">
            <form method="post" action="<?php echo e(url('/settings/vehicle-types')); ?>">
                <?php echo e(csrf_field()); ?>

            <div class="modal-body text-center modal-padding">
                <div class="icon-delete text-center"><i class="fas fa-trash"></i></div>
                <p>Are you sure you want to delete this?</p>
                <input type="hidden" name="vehicle_id" value="<?php echo e($d->id); ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-default">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
            </form>
        </div>
    </div>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>